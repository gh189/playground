package main

import (
	"context"
	"log"
	"os"

	"github.com/robfig/cron/v3"
)

// runAllPlugins scans data/plugins for binaries and runs each one in turn via
// runPluginBinary, which persists the resulting event (and evidence image on
// success) to the database. Errors for individual plugins are logged but do
// not stop the remaining plugins from running.
func runAllPlugins() {
	ctx := context.Background()

	entries, err := os.ReadDir(binPath("data/plugins"))
	if err != nil {
		log.Printf("[scheduler] failed to read data/plugins directory: %v", err)
		return
	}

	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		name := entry.Name()
		log.Printf("[scheduler] running plugin %q…", name)
		if _, _, summary, _, err := runPluginBinary(ctx, name); err != nil {
			log.Printf("[scheduler] plugin %q failed: %v", name, err)
		} else {
			log.Printf("[scheduler] plugin %q finished: %s", name, summary)
		}
	}
}

// startScheduler starts the cron scheduler and returns it so the caller
// can stop it on shutdown.
func startScheduler() *cron.Cron {
	c := cron.New()

	if _, err := c.AddFunc("@every 3h", func() {
		log.Println("[scheduler] tick: starting scheduled run of all plugins in data/plugins")
		runAllPlugins()
		log.Println("[scheduler] tick: finished scheduled run of all plugins")
	}); err != nil {
		log.Fatalf("[scheduler] failed to register plugin run job: %v", err)
	}

	c.Start()
	log.Println("[scheduler] started: all plugins will run every 3 hours")
	return c
}
