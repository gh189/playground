package main

import (
	"log"

	"github.com/robfig/cron/v3"
)

// startScheduler starts the cron scheduler and returns it so the caller
// can stop it on shutdown.
func startScheduler() *cron.Cron {
	c := cron.New()

	if _, err := c.AddFunc("@every 1m", func() {
		log.Println("[scheduler] running scheduled plugin check — scanning for pending jobs…")
	}); err != nil {
		log.Fatalf("[scheduler] failed to register job: %v", err)
	}

	c.Start()
	log.Println("[scheduler] started — jobs will run every minute")
	return c
}
