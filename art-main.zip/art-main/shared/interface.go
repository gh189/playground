package shared

import (
	"net/rpc"
	"time"

	"github.com/hashicorp/go-plugin"
)

// ── Step ─────────────────────────────────────────────────────────────────────

// Step represents a single execution step reported by a plugin.
type Step struct {
	Name      string    `json:"name"`
	StartTime time.Time `json:"start_time"`
	EndTime   time.Time `json:"end_time"`
	Success   bool      `json:"success"`
	Output    string    `json:"output"`
}

// ── Runner ───────────────────────────────────────────────────────────────────

// Runner is the interface that both host and plugins agree on.
type Runner interface {
	Run(name string) ([]Step, error)
	BeforeTest(name string) (string, error)
}

// RunnerRPC is the client stub that runs in the host process.
type RunnerRPC struct{ client *rpc.Client }

func (r *RunnerRPC) Run(name string) ([]Step, error) {
	var resp []Step
	err := r.client.Call("Plugin.Run", name, &resp)
	return resp, err
}

func (r *RunnerRPC) BeforeTest(name string) (string, error) {
	var resp string
	err := r.client.Call("Plugin.BeforeTest", name, &resp)
	return resp, err
}

// RunnerRPCServer is the server that wraps the real implementation inside the plugin process.
type RunnerRPCServer struct{ Impl Runner }

func (s *RunnerRPCServer) Run(name string, resp *[]Step) error {
	result, err := s.Impl.Run(name)
	*resp = result
	return err
}

func (s *RunnerRPCServer) BeforeTest(name string, resp *string) error {
	result, err := s.Impl.BeforeTest(name)
	*resp = result
	return err
}

// RunnerPlugin wires the Runner interface into go-plugin's dispatch layer.
type RunnerPlugin struct{ Impl Runner }

func (p *RunnerPlugin) Server(*plugin.MuxBroker) (interface{}, error) {
	return &RunnerRPCServer{Impl: p.Impl}, nil
}

func (p *RunnerPlugin) Client(_ *plugin.MuxBroker, c *rpc.Client) (interface{}, error) {
	return &RunnerRPC{client: c}, nil
}

// ── Shared configuration ─────────────────────────────────────────────────────

// Handshake is shared between host and plugins to verify compatibility.
var Handshake = plugin.HandshakeConfig{
	ProtocolVersion:  1,
	MagicCookieKey:   "ART_PLUGIN",
	MagicCookieValue: "runner",
}

// PluginMap is used by the host to declare which plugin interfaces it supports.
// Impl is intentionally nil here — the host only needs the type for dispensing,
// not a concrete implementation.
var PluginMap = map[string]plugin.Plugin{
	"runner": &RunnerPlugin{},
}
