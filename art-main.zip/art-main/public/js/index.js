$(function () {
  // ── Upload ──────────────────────────────────────────────
  var $fileInput   = $('#file-input');
  var $uploadBtn   = $('#upload-btn');
  var $nameLabel   = $('#file-name-label');
  var $toast       = $('#upload-toast');

  function showToast(msg, type) {
    $toast.attr('class', 'upload-toast upload-toast--' + type).text(msg).addClass('upload-toast--show');
    if (type !== 'info') {
      setTimeout(function () { $toast.removeClass('upload-toast--show'); }, 4000);
    }
  }

  $fileInput.on('change', function () {
    var file = this.files[0];
    if (file) {
      $nameLabel.text(file.name);
      $uploadBtn.prop('disabled', false);
    } else {
      $nameLabel.text('No file selected');
      $uploadBtn.prop('disabled', true);
    }
    $toast.removeClass('upload-toast--show');
  });

  $uploadBtn.on('click', function () {
    var file = $fileInput[0].files[0];
    if (!file) return;

    var fd = new FormData();
    fd.append('file', file);

    $uploadBtn.prop('disabled', true).text('Uploading…');
    showToast('Uploading ' + file.name + '…', 'info');

    $.ajax({
      url: '/api/upload',
      type: 'POST',
      data: fd,
      processData: false,
      contentType: false
    })
    .done(function (res) {
      showToast('✓ ' + (res.message || 'Uploaded successfully') + ': ' + (res.plugin || file.name), 'success');
      $fileInput.val('');
      $nameLabel.text('No file selected');
      loadPlugins();
    })
    .fail(function (xhr) {
      var err = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : 'Upload failed';
      showToast('✗ ' + err, 'error');
      $uploadBtn.prop('disabled', false);
    })
    .always(function () {
      $uploadBtn.text('⬆ Upload');
    });
  });

  // ── Plugins ─────────────────────────────────────────────
  function loadPlugins() {
    $.getJSON('/api/plugins')
        .done(function (data) {
          const $grid = $('#plugin-grid').empty();
          const plugins = data.plugins || [];

          if (plugins.length === 0) {
            $grid.append('<p class="loading-text">No plugins found.</p>');
            return;
          }

          plugins.forEach(function (p) {
            const safeName = $('<span>').text(p.name).html();
            const $btn = $('<button class="btn run-btn">▶ Run</button>');

            $btn.on('click', function () {
              $btn.prop('disabled', true).text('Running…');
              $.ajax({ url: '/api/plugins/' + encodeURIComponent(p.name), method: 'POST' })
                  .done(function (res) {
                    $btn.text('✓ Done').addClass('run-btn--done');
                    console.log('[' + p.name + '] result:', res.result);
                    loadEvents();
                  })
                  .fail(function (xhr) {
                    $btn.text('✗ Failed').addClass('run-btn--error');
                    console.error('[' + p.name + '] error:', xhr.responseJSON && xhr.responseJSON.error);
                  })
                  .always(function () {
                    setTimeout(function () {
                      $btn.prop('disabled', false).text('▶ Run')
                          .removeClass('run-btn--done run-btn--error');
                    }, 3000);
                  });
            });

            const $card = $(
                '<div class="card">' +
                '<div class="card-icon">🔌</div>' +
                '<h3>' + safeName + '</h3>' +
                '<p>Binary plugin available in <code>./bin</code>.</p>' +
                '</div>'
            ).append($btn);

            $grid.append($card);
          });
        })
        .fail(function () {
          $('#plugin-grid').html('<p class="loading-text">Failed to load plugins.</p>');
        });
  }

  // ── Modal ────────────────────────────────────────────────
  const $modal = $('#event-modal');

  function openModal(event) {
    $('#modal-id').text(event.id);
    $('#modal-timestamp').text(new Date(event.timestamp).toLocaleString());
    $('#modal-plugin').text(event.plugin);
    $('#modal-details').text(event.details);
    $modal.addClass('modal--open');
  }

  function closeModal() {
    $modal.removeClass('modal--open');
  }

  $modal.on('click', function (e) {
    if ($(e.target).is($modal)) closeModal();
  });

  $('.modal-close').on('click', closeModal);

  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
  });

  // ── History ──────────────────────────────────────────────
  function loadEvents() {
    $.getJSON('/api/events')
      .done(function (events) {
        const $tbody = $('#events-tbody').empty();
        if (!events || events.length === 0) {
          $tbody.append('<tr><td colspan="5" class="loading-text">No events yet.</td></tr>');
          return;
        }
        events.slice().reverse().forEach(function (e) {
          const ts = new Date(e.timestamp).toLocaleString();
          const safePlugin  = $('<span>').text(e.plugin).html();
          const safeDetails = $('<span>').text(e.details).html();
          const $btn = $('<button class="btn event-detail-btn">View</button>');
          $btn.on('click', function () { openModal(e); });

          const $row = $(
            '<tr>' +
            '<td>' + e.id + '</td>' +
            '<td>' + ts + '</td>' +
            '<td>' + safePlugin + '</td>' +
            '<td>' + safeDetails + '</td>' +
            '<td></td>' +
            '</tr>'
          );
          $row.find('td:last').append($btn);
          $tbody.append($row);
        });
      })
      .fail(function () {
        $('#events-tbody').html('<tr><td colspan="5" class="loading-text">Failed to load events.</td></tr>');
      });
  }

  loadPlugins();
  loadEvents();
});
