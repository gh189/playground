$(function () {
  // ── Upload ──────────────────────────────────────────────
  var $fileInput      = $('#file-input');
  var $uploadBtn      = $('#upload-btn');
  var $nameLabel      = $('#file-name-label');
  var $toast          = $('#upload-toast');
  var $pluginName     = $('#plugin-name');
  var $pluginDesc     = $('#plugin-desc');
  var $pluginService  = $('#plugin-service');

  function showToast(msg, type) {
    $toast.attr('class', 'upload-toast upload-toast--' + type).text(msg).addClass('upload-toast--show');
    if (type !== 'info') {
      setTimeout(function () { $toast.removeClass('upload-toast--show'); }, 4000);
    }
  }

  function refreshUploadBtn() {
    var hasFile = $fileInput[0].files.length > 0;
    var hasName = $pluginName.val().trim() !== '';
    $uploadBtn.prop('disabled', !(hasName && hasFile));
  }

  $fileInput.on('change', function () {
    var file = this.files[0];
    if (file) {
      $nameLabel.text(file.name);
      if ($pluginName.val().trim() === '') {
        $pluginName.val(file.name.replace(/\.[^/.]+$/, ''));
      }
    } else {
      $nameLabel.text('No file selected');
    }
    $toast.removeClass('upload-toast--show');
    refreshUploadBtn();
  });

  $pluginName.on('input', refreshUploadBtn);

  $uploadBtn.on('click', function () {
    var file = $fileInput[0].files[0];
    var name = $pluginName.val().trim();

    if (!name) { showToast('Please enter a plugin name.', 'error'); return; }
    if (!file)  { showToast('Please select a binary file.', 'error'); return; }

    var fd = new FormData();
    fd.append('name',        name);
    fd.append('description', $pluginDesc.val().trim());
    fd.append('service',     $pluginService.val().trim());
    fd.append('file',        file);

    $uploadBtn.prop('disabled', true).text('Uploading…');
    showToast('Uploading ' + name + '…', 'info');

    $.ajax({
      url: '/api/upload',
      type: 'POST',
      data: fd,
      processData: false,
      contentType: false
    })
    .done(function (res) {
      showToast('✓ ' + (res.message || 'Uploaded successfully') + ': ' + (res.plugin || name), 'success');
      $fileInput.val('');
      $nameLabel.text('No file selected');
      $pluginName.val('');
      $pluginDesc.val('');
      $pluginService.val('');
      refreshUploadBtn();
      loadPlugins();
    })
    .fail(function (xhr) {
      var err;
      if (xhr.status === 401) {
        err = 'You are not allowed to upload plugins. Please log in with an authorized account.';
      } else {
        err = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : 'Upload failed';
      }
      showToast('✗ ' + err, 'error');
      $uploadBtn.prop('disabled', false);
    })
    .always(function () {
      $uploadBtn.text('⬆ Upload');
    });
  });

  // ── Plugins ─────────────────────────────────────────────
  // Shared map: plugin filename → latest event (populated by loadEvents)
  var latestEventByPlugin = {};

  function applyCardStates() {
    $('#plugin-grid .card[data-filename]').each(function () {
      const filename = $(this).data('filename');
      const ev = latestEventByPlugin[filename];
      $(this).removeClass('card--pass card--fail');
      if (ev !== undefined) {
        $(this).addClass(ev.success ? 'card--pass' : 'card--fail');
      }
    });
  }

  function loadPlugins() {
    $.getJSON('/api/plugins')
        .done(function (data) {
          const $grid = $('#plugin-grid').empty();
          const plugins = Array.isArray(data) ? data : [];

          if (plugins.length === 0) {
            $grid.append('<p class="loading-text">No plugins found.</p>');
            return;
          }

          plugins.forEach(function (p) {
            const safeDesc     = $('<span>').text(p.description || '').html();
            const safeService  = $('<span>').text(p.service  || '').html();

            const $detailsBtn = $('<button class="details-btn">ℹ Details</button>');
            const $logsBtn    = $('<button class="btn logs-btn">📄 Logs</button>');
            const $runBtn     = $('<button class="btn run-btn">▶ Run</button>');

            $detailsBtn.on('click', function () { openPluginModal(p); });

            $logsBtn.on('click', function () {
              window.open('/api/logs/' + encodeURIComponent(p.filename || p.name), '_blank');
            });

            $runBtn.on('click', function () {
              $runBtn.prop('disabled', true).text('Running…');
              $.ajax({ url: '/api/plugins/' + encodeURIComponent(p.filename || p.name), method: 'POST' })
                  .done(function () {
                    $runBtn.text('✓ Done').addClass('run-btn--done');
                    loadEvents();
                  })
                  .fail(function (xhr) {
                    $runBtn.text('✗ Failed').addClass('run-btn--error');
                    console.error('[' + p.name + '] error:', xhr.responseJSON && xhr.responseJSON.error);
                    // A BeforeTest/Run failure still records an events row
                    // (empty steps, success=false), so refresh the history
                    // and card state to reflect it.
                    loadEvents();
                  })
                  .always(function () {
                    setTimeout(function () {
                      $runBtn.prop('disabled', false).text('▶ Run')
                          .removeClass('run-btn--done run-btn--error');
                    }, 3000);
                  });
            });

            const $card = $('<div class="card"></div>')
              .attr('data-filename', p.filename || p.name)
              .append(
                $('<div class="card-header"></div>').append(
                  $('<div class="card-icon">🔌</div>'),
                  $('<div class="card-meta"></div>').append(
                    $('<h3></h3>').text(p.name || ''),
                    safeService ? $('<span class="card-service-badge"></span>').text(p.service) : null
                  )
                ),
                safeDesc
                  ? $('<div class="card-body"></div>').append(
                      $('<p class="card-desc"></p>').text(p.description)
                    )
                  : null,
                $('<div class="card-footer"></div>').append($detailsBtn, $logsBtn, $runBtn)
              );

            $grid.append($card);
          });

          applyCardStates();
        })
        .fail(function () {
          $('#plugin-grid').html('<p class="loading-text">Failed to load plugins.</p>');
        });
  }

  // ── Plugin modal ─────────────────────────────────────────
  const $pluginModal = $('#plugin-modal');

  function openPluginModal(p) {
    $('#pmodal-name').text(p.name || '—');
    $('#pmodal-desc').text(p.description || '—');
    $('#pmodal-service').text(p.service || '—');
    $pluginModal.addClass('modal--open');
  }

  function closePluginModal() { $pluginModal.removeClass('modal--open'); }

  $pluginModal.on('click', function (e) {
    if ($(e.target).is($pluginModal)) closePluginModal();
  });
  $('.plugin-modal-close').on('click', closePluginModal);

  // ── Event modal ──────────────────────────────────────────
  const $modal = $('#event-modal');
  let currentEventId = null;

  function openModal(event) {
    currentEventId = event.id;
    $('#modal-id').text(event.id);
    $('#modal-timestamp').text(new Date(event.timestamp).toLocaleString());
    $('#modal-plugin').text(event.plugin);
    $('#modal-details').text(event.details);

    // Render steps table
    const $tbody = $('#modal-steps-tbody').empty();
    const steps = event.steps || [];
    if (steps.length === 0) {
      $tbody.append('<tr><td colspan="5" style="text-align:center;color:#9aa5b4;padding:12px">No steps recorded.</td></tr>');
    } else {
      steps.forEach(function (s) {
        const start    = new Date(s.start_time);
        const end      = new Date(s.end_time);
        const durMs    = end - start;
        const durText  = isNaN(durMs) ? '—' : (durMs < 1000 ? durMs + ' ms' : (durMs / 1000).toFixed(2) + ' s');
        const statusCls = s.success ? 'step-status--pass' : 'step-status--fail';
        const statusTxt = s.success ? '✓ Pass' : '✗ Fail';
        const $row = $('<tr></tr>').append(
          $('<td></td>').text(s.name),
          $('<td></td>').text(start.toLocaleTimeString()),
          $('<td></td>').text(durText),
          $('<td></td>').append($('<span></span>').addClass(statusCls).text(statusTxt)),
          $('<td class="step-output"></td>').text(s.output || '—')
        );
        $tbody.append($row);
      });
    }

    // The Evidence section (and the Ticket/Attach controls nested inside it)
    // is only relevant (and only generated server-side) when all steps
    // succeeded, so hide it entirely otherwise.
    const $evidenceSection = $('#modal-evidence-section');
    $('#modal-ticket-input').val('');
    $('#modal-ticket-msg').removeClass('ticket-msg--show ticket-msg--success ticket-msg--error').text('');
    if (event.success) {
      $evidenceSection.show();
      loadEvidence(event.id);
    } else {
      $evidenceSection.hide();
    }

    $modal.addClass('modal--open');
  }

  function showTicketMsg(msg, type) {
    $('#modal-ticket-msg')
      .attr('class', 'ticket-msg ticket-msg--show ticket-msg--' + type)
      .text(msg);
  }

  // Send the ticket entered by the user, along with the current event id,
  // to the server so it can be attached to the Jira ticket. The ticket input
  // is always cleared afterwards, whether the request succeeds or fails.
  $('#modal-attach-btn').on('click', function () {
    const $ticketInput = $('#modal-ticket-input');
    const ticket = $ticketInput.val().trim();
    if (!ticket || currentEventId == null) return;

    fetch('/api/jira', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ticket: ticket, event_id: currentEventId })
    })
      .then(function (res) {
        if (!res.ok) throw new Error('request failed');
        showTicketMsg('Attached to ticket ' + ticket + '.', 'success');
      })
      .catch(function () {
        showTicketMsg('Failed to attach to ticket ' + ticket + '.', 'error');
      })
      .finally(function () {
        $ticketInput.val('');
      });
  });

  // Fetch the evidence PNG for the given event id and show it, or fall
  // back to the "no evidence" message if it's missing/fails to load.
  function loadEvidence(eventId) {
    const $img = $('#modal-evidence-img');
    const $empty = $('#modal-evidence-empty');

    $img.removeClass('evidence-img--visible').attr('src', '');
    $empty.hide();

    fetch('/api/evidence/' + encodeURIComponent(eventId), { credentials: 'same-origin' })
      .then(function (res) {
        if (!res.ok) throw new Error('no evidence');
        return res.blob();
      })
      .then(function (blob) {
        const url = URL.createObjectURL(blob);
        $img.attr('src', url).addClass('evidence-img--visible');
      })
      .catch(function () {
        $empty.show();
      });
  }

  function closeModal() {
    $modal.removeClass('modal--open');
    const $img = $('#modal-evidence-img');
    const src = $img.attr('src');
    if (src) URL.revokeObjectURL(src);
    $img.removeClass('evidence-img--visible').attr('src', '');
  }

  $modal.on('click', function (e) {
    if ($(e.target).is($modal)) closeModal();
  });
  $('.modal-close').on('click', closeModal);

  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') { closeModal(); closePluginModal(); }
  });

  // ── History ──────────────────────────────────────────────
  function loadEvents() {
    $.getJSON('/api/events')
      .done(function (events) {
        const $tbody = $('#events-tbody').empty();
        if (!events || events.length === 0) {
          $tbody.append('<tr><td colspan="6" class="loading-text">No events yet.</td></tr>');
          latestEventByPlugin = {};
          applyCardStates();
          return;
        }

        // Build latest-event map (events are in ascending ID order; last write wins)
        latestEventByPlugin = {};
        events.forEach(function (e) { latestEventByPlugin[e.plugin] = e; });
        applyCardStates();
        events.slice().reverse().forEach(function (e) {
          const ts         = new Date(e.timestamp).toLocaleString();
          const safePlugin = $('<span>').text(e.plugin).html();
          const steps      = e.steps || [];
          const total      = steps.length;
          const passed     = steps.filter(function (s) { return s.success; }).length;
          const allPass    = total > 0 && passed === total;
          const badgeCls   = allPass ? 'result-badge--pass' : 'result-badge--fail';
          const badgeIcon  = allPass ? '✓' : '✗';
          const badgeTxt   = total > 0 ? badgeIcon + ' ' + passed + '/' + total + ' steps' : (e.details || '—');

          const successCls = e.success ? 'success-dot--pass' : 'success-dot--fail';
          const successTxt = e.success ? 'Pass' : 'Fail';

          const $btn = $('<button class="btn event-detail-btn">View</button>');
          $btn.on('click', function () { openModal(e); });

          const $row = $('<tr></tr>').append(
            $('<td></td>').text(e.id),
            $('<td></td>').text(ts),
            $('<td></td>').html(safePlugin),
            $('<td></td>').append($('<span class="success-dot"></span>').addClass(successCls).text(successTxt)),
            $('<td></td>').append($('<span class="result-badge"></span>').addClass(badgeCls).text(badgeTxt)),
            $('<td></td>').append($btn)
          );
          $tbody.append($row);
        });
      })
      .fail(function () {
        $('#events-tbody').html('<tr><td colspan="6" class="loading-text">Failed to load events.</td></tr>');
      });
  }

  loadPlugins();
  loadEvents();
});

// ── Login modal ──────────────────────────────────────────────────────────────
$(function () {
  const $loginModal    = $('#login-modal');
  const $loginError    = $('#login-error');
  const $submitBtn     = $('#login-submit-btn');
  const $loginBtn      = $('#login-btn');
  const $loggedInArea  = $('#logged-in-area');
  const $authUsername  = $('#auth-username');

  function showLoggedIn(username) {
    $authUsername.text(username);
    $loginBtn.hide();
    $loggedInArea.show();
  }

  function showLoggedOut() {
    $loggedInArea.hide();
    $loginBtn.show();
  }

  // Check login status on page load.
  $.get('/api/login')
    .done(function (res) { showLoggedIn(res.claims && res.claims.id || 'User'); })
    .fail(showLoggedOut);

  // ── Login modal open / close ──
  function openLoginModal() {
    $('#login-username').val('');
    $('#login-password').val('');
    $loginError.text('');
    $loginModal.addClass('modal--open');
    $('#login-username').focus();
  }
  function closeLoginModal() { $loginModal.removeClass('modal--open'); }

  $loginBtn.on('click', openLoginModal);
  $('.login-modal-close').on('click', closeLoginModal);
  $loginModal.on('click', function (e) {
    if ($(e.target).is($loginModal)) closeLoginModal();
  });
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') closeLoginModal();
  });

  // ── Login form submit ──
  $('#login-form').on('submit', function (e) {
    e.preventDefault();
    $loginError.text('');
    $submitBtn.prop('disabled', true).text('Signing in…');

    $.ajax({
      url: '/api/login',
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({
        username: $('#login-username').val().trim(),
        password: $('#login-password').val()
      })
    })
    .done(function () {
      closeLoginModal();
      showLoggedIn($('#login-username').val().trim());
    })
    .fail(function (xhr) {
      const msg = xhr.responseJSON && xhr.responseJSON.error
        ? xhr.responseJSON.error
        : 'Login failed. Please try again.';
      $loginError.text(msg);
    })
    .always(function () {
      $submitBtn.prop('disabled', false).text('Sign in');
    });
  });

  // ── Logout ──
  $('#logout-btn').on('click', function () {
    $.post('/api/logout').always(showLoggedOut);
  });

  // ── Info Modal (logo click) ──
  function checkDbHealth() {
    const $indicator = $('#db-status-indicator');
    const $text = $('#db-status-text');
    $indicator.attr('class', 'status-indicator status-indicator--unknown').attr('title', 'Checking…');
    $text.text('Checking…');

    $.get('/api/pgmaker/health')
      .done(function () {
        $indicator.attr('class', 'status-indicator status-indicator--healthy').attr('title', 'Healthy');
        $text.text('Healthy');
      })
      .fail(function () {
        $indicator.attr('class', 'status-indicator status-indicator--unhealthy').attr('title', 'Unhealthy');
        $text.text('Unhealthy');
      });
  }

  $('#logo-link').on('click', function (e) {
    e.preventDefault();
    $('#info-modal').fadeIn(150);
    checkDbHealth();
  });

  $('#info-modal-close, #info-modal').on('click', function (e) {
    if (e.target === this) $('#info-modal').fadeOut(150);
  });

  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') $('#info-modal').fadeOut(150);
  });
});
