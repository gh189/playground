window.onload = function() {
  //<editor-fold desc="Changeable Configuration Block">

  // the following lines will be replaced by docker/configurator, when it runs in a docker-container
  window.ui = SwaggerUIBundle({
    url: "/swagger/swagger.json",
    dom_id: '#swagger-ui',
    deepLinking: true,
    presets: [
      SwaggerUIBundle.presets.apis,
      SwaggerUIStandalonePreset
    ],
    plugins: [
      SwaggerUIBundle.plugins.DownloadUrl
    ],
    layout: "StandaloneLayout",
    onComplete: function () {
      // The "jwt" cookie is HttpOnly, so it can't be read from JS and
      // can't be set via preauthorizeApiKey's value. The browser already
      // sends it automatically on same-origin "Try it out" requests.
      // Here we just check login status and, if a valid session exists,
      // mark the cookieAuth scheme as authorized so the UI padlocks show
      // "authorized" without requiring the user to click Authorize.
      var wasAuthorized = false;

      function isCookieAuthAuthorized() {
        try {
          return window.ui.authSelectors.authorized().has('cookieAuth');
        } catch (e) {
          return false;
        }
      }

      // Watch the Swagger UI auth store. When the user clicks "Logout" in
      // the Authorize popup, cookieAuth is removed from the authorized map.
      // That's our cue to actually clear the server-side "jwt" cookie too,
      // since Swagger UI itself has no knowledge of our HttpOnly cookie.
      var store = typeof window.ui.getStore === 'function' ? window.ui.getStore() : null;
      if (store && typeof store.subscribe === 'function') {
        store.subscribe(function () {
          var isAuthorized = isCookieAuthAuthorized();
          if (wasAuthorized && !isAuthorized) {
            fetch('/api/logout', { method: 'POST', credentials: 'same-origin' })
              .catch(function () { /* best effort */ });
          }
          wasAuthorized = isAuthorized;
        });
      }

      fetch('/api/login', { credentials: 'same-origin' })
        .then(function (res) { return res.ok ? res.json() : null; })
        .then(function (data) {
          if (data && data.loggedIn) {
            window.ui.preauthorizeApiKey('cookieAuth', 'jwt (from cookie)');
            wasAuthorized = true;
          }
        })
        .catch(function () { /* not logged in or request failed; ignore */ });
    }
  });

  //</editor-fold>
};
