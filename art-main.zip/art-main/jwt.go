package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"os"
	"path/filepath"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// keys, err := LoadJWTKeys("private.pem", "public.pem")
// token, err := GenerateJWT(keys, map[string]any{"sub": "user123", "role": "admin"}, time.Hour*24)
// claims, err := ParseJWT(keys, token)

// EnsureJWTKeys generates a 4096-bit RSA key pair and writes them as PEM files
// if either file is missing. The parent directory is created automatically.
func EnsureJWTKeys(privateKeyPath, publicKeyPath string) error {
	if _, err := os.Stat(privateKeyPath); err == nil {
		if _, err := os.Stat(publicKeyPath); err == nil {
			return nil // both files already exist
		}
	}

	if err := os.MkdirAll(filepath.Dir(privateKeyPath), 0700); err != nil {
		return err
	}

	privateKey, err := rsa.GenerateKey(rand.Reader, 4096)
	if err != nil {
		return err
	}

	// Write private key (PKCS#1, PEM, owner-read-only).
	privFile, err := os.OpenFile(privateKeyPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0600)
	if err != nil {
		return err
	}
	defer privFile.Close()
	if err := pem.Encode(privFile, &pem.Block{
		Type:  "RSA PRIVATE KEY",
		Bytes: x509.MarshalPKCS1PrivateKey(privateKey),
	}); err != nil {
		return err
	}

	// Write public key (PKIX, PEM).
	pubDER, err := x509.MarshalPKIXPublicKey(&privateKey.PublicKey)
	if err != nil {
		return err
	}
	pubFile, err := os.OpenFile(publicKeyPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0644)
	if err != nil {
		return err
	}
	defer pubFile.Close()
	return pem.Encode(pubFile, &pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: pubDER,
	})
}

// JWTKeys holds the loaded RSA key pair.
type JWTKeys struct {
	PrivateKey *rsa.PrivateKey
	PublicKey  *rsa.PublicKey
}

// LoadJWTKeys loads RSA private and public keys from PEM files.
func LoadJWTKeys(privateKeyPath, publicKeyPath string) (*JWTKeys, error) {
	privBytes, err := os.ReadFile(privateKeyPath)
	if err != nil {
		return nil, err
	}
	privateKey, err := jwt.ParseRSAPrivateKeyFromPEM(privBytes)
	if err != nil {
		return nil, err
	}

	pubBytes, err := os.ReadFile(publicKeyPath)
	if err != nil {
		return nil, err
	}
	publicKey, err := jwt.ParseRSAPublicKeyFromPEM(pubBytes)
	if err != nil {
		return nil, err
	}

	return &JWTKeys{PrivateKey: privateKey, PublicKey: publicKey}, nil
}

// GenerateJWT creates a signed JWT token using RS256 with the given claims.
// expires sets the token lifetime; pass 0 to use the default of 1 hour.
func GenerateJWT(keys *JWTKeys, claims map[string]any, expires time.Duration) (string, error) {
	if expires == 0 {
		expires = time.Hour
	}

	mapClaims := jwt.MapClaims{
		"iat": jwt.NewNumericDate(time.Now()),
		"exp": jwt.NewNumericDate(time.Now().Add(expires)),
	}
	for k, v := range claims {
		mapClaims[k] = v
	}

	token := jwt.NewWithClaims(jwt.SigningMethodRS256, mapClaims)
	return token.SignedString(keys.PrivateKey)
}

// ParseJWT validates a JWT token string and returns its claims.
func ParseJWT(keys *JWTKeys, tokenString string) (jwt.MapClaims, error) {
	token, err := jwt.ParseWithClaims(tokenString, jwt.MapClaims{}, func(t *jwt.Token) (any, error) {
		if _, ok := t.Method.(*jwt.SigningMethodRSA); !ok {
			return nil, jwt.ErrSignatureInvalid
		}
		return keys.PublicKey, nil
	})
	if err != nil {
		return nil, err
	}

	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		return claims, nil
	}
	return nil, jwt.ErrTokenInvalidClaims
}
