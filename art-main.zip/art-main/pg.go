package main

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"
)

//pg := PG{Username: "app", Password: "secret", Host: "localhost", Port: 5432, Database: "mydb"}
//
//rows, err := pg.Query(ctx, "SELECT id, name FROM users WHERE active = $1", true)
//affected, err := pg.Exec(ctx, "UPDATE users SET name=$1 WHERE id=$2", "Alice", 42)

type PG struct {
	Username string
	Password string
	Host     string
	Port     int
	Database string
	pool     *pgxpool.Pool
}

func (pg *PG) connect() error {
	if pg.pool != nil {
		return nil
	}
	dsn := fmt.Sprintf("postgres://%s:%s@%s:%d/%s",
		pg.Username, pg.Password, pg.Host, pg.Port, pg.Database)
	pool, err := pgxpool.New(context.Background(), dsn)
	if err != nil {
		return fmt.Errorf("pgxpool.New: %w", err)
	}
	pg.pool = pool
	return nil
}

// Query runs a SELECT (or any row-returning) statement and returns the results
// as a slice of maps keyed by column name.
func (pg *PG) Query(ctx context.Context, sql string, args ...any) ([]map[string]any, error) {
	if err := pg.connect(); err != nil {
		return nil, err
	}
	rows, err := pg.pool.Query(ctx, sql, args...)
	if err != nil {
		return nil, fmt.Errorf("query: %w", err)
	}
	defer rows.Close()

	var results []map[string]any
	fields := rows.FieldDescriptions()
	for rows.Next() {
		values, err := rows.Values()
		if err != nil {
			return nil, fmt.Errorf("rows.Values: %w", err)
		}
		row := make(map[string]any, len(fields))
		for i, f := range fields {
			row[string(f.Name)] = values[i]
		}
		results = append(results, row)
	}
	return results, rows.Err()
}

// Exec runs an INSERT, UPDATE, DELETE, or any non-row-returning statement and
// returns the number of rows affected.
func (pg *PG) Exec(ctx context.Context, sql string, args ...any) (int64, error) {
	if err := pg.connect(); err != nil {
		return 0, err
	}
	tag, err := pg.pool.Exec(ctx, sql, args...)
	if err != nil {
		return 0, fmt.Errorf("exec: %w", err)
	}
	return tag.RowsAffected(), nil
}
