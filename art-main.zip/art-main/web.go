package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"time"

	"embed"

	hclog "github.com/hashicorp/go-hclog"
	goplugin "github.com/hashicorp/go-plugin"

	"github.com/gin-gonic/gin"

	"art/shared"
)

//go:embed public
var staticFiles embed.FS

// Event records a single occurrence captured by the framework.
type Event struct {
	ID        int           `json:"id"`
	Timestamp time.Time     `json:"timestamp"`
	Plugin    string        `json:"plugin"`
	Details   string        `json:"details"`
	Steps     []shared.Step `json:"steps"`
	Success   bool          `json:"success"`
}

// events is the in-memory event log, protected by eventsMu.
// nextEventID is the auto-increment counter for Event.ID.
var (
	events      []Event
	eventsMu    sync.Mutex
	nextEventID int = 1
)

// listEvents returns all recorded events as a JSON array.
func listEvents(c *gin.Context) {
	eventsMu.Lock()
	snapshot := make([]Event, len(events))
	copy(snapshot, events)
	eventsMu.Unlock()

	c.JSON(http.StatusOK, snapshot)
}

// listPlugins reads data/info.json and returns full plugin metadata.
// Falls back to scanning ./data/uploads for binaries that have no metadata entry.
func listPlugins(c *gin.Context) {
	type pluginMeta struct {
		Name        string `json:"name"`
		Description string `json:"description"`
		Service     string `json:"service"`
		Filename    string `json:"filename"`
	}

	var plugins []pluginMeta

	if raw, err := os.ReadFile("./data/info.json"); err == nil {
		_ = json.Unmarshal(raw, &plugins)
	}

	if plugins == nil {
		plugins = []pluginMeta{}
	}

	c.JSON(http.StatusOK, plugins)
}

// runPlugin launches the named binary plugin from ./data/uploads, calls Runner.Run, and
// returns the result as JSON.
func runPlugin(c *gin.Context) {
	name := c.Param("name")
	pluginPath := filepath.Join("./data/uploads", name)

	if _, err := os.Stat(pluginPath); os.IsNotExist(err) {
		c.JSON(http.StatusNotFound, gin.H{"error": fmt.Sprintf("plugin %q not found in ./data/uploads", name)})
		return
	}

	client := goplugin.NewClient(&goplugin.ClientConfig{
		HandshakeConfig: shared.Handshake,
		Plugins:         shared.PluginMap,
		Cmd:             exec.Command(pluginPath),
		AllowedProtocols: []goplugin.Protocol{
			goplugin.ProtocolNetRPC,
		},
		Logger: hclog.New(&hclog.LoggerOptions{
			Level:  hclog.Warn,
			Output: os.Stderr,
		}),
	})
	defer client.Kill()

	rpcClient, err := client.Client()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("plugin client error: %v", err)})
		return
	}

	raw, err := rpcClient.Dispense("runner")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("dispense error: %v", err)})
		return
	}

	runner := raw.(shared.Runner)
	beforeMsg, err := runner.BeforeTest(shared.RunContext{Timeout: 10})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("before_test error: %v", err)})
		return
	}

	steps, err := runner.Run(shared.RunContext{Timeout: 10})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("run error: %v", err)})
		return
	}

	// Derive a summary message and overall success from the returned steps.
	successCount := 0
	for _, s := range steps {
		if s.Success {
			successCount++
		}
	}
	allSuccess := len(steps) > 0 && successCount == len(steps)
	summary := fmt.Sprintf("%d/%d steps passed", successCount, len(steps))

	c.JSON(http.StatusOK, gin.H{"plugin": name, "before_test": beforeMsg, "steps": steps, "result": summary})

	eventsMu.Lock()
	ev := Event{ID: nextEventID, Timestamp: time.Now(), Plugin: name, Details: summary, Steps: steps, Success: allSuccess}
	events = append(events, ev)
	nextEventID++
	eventsMu.Unlock()

	// Save event details as a PNG image.
	imgText := fmt.Sprintf("ID: %d\nTimestamp: %s\nPlugin: %s\nDetails: %s",
		ev.ID, ev.Timestamp.Format(time.RFC3339), ev.Plugin, ev.Details)
	imgPath := fmt.Sprintf("data/event-%d.png", ev.ID)
	if err := GenerateTextImage(imgText, imgPath); err != nil {
		log.Printf("failed to save event image: %v", err)
	}
}

// uploadPlugin accepts a multipart file upload and saves it to ./data/uploads.
// It also persists plugin metadata (name, description, service, filename)
// to ./data/info.json.
func uploadPlugin(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": fmt.Sprintf("failed to get file: %v", err)})
		return
	}

	uploadDir := "./data/uploads"
	if err := os.MkdirAll(uploadDir, 0755); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("failed to create upload directory: %v", err)})
		return
	}

	dst := filepath.Join(uploadDir, file.Filename)
	if err := c.SaveUploadedFile(file, dst); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("failed to save file: %v", err)})
		return
	}

	// Make the uploaded binary executable.
	if err := os.Chmod(dst, 0755); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("failed to chmod file: %v", err)})
		return
	}

	// Persist plugin metadata to bin/info.json.
	type pluginMeta struct {
		Name        string `json:"name"`
		Description string `json:"description"`
		Service     string `json:"service"`
		Filename    string `json:"filename"`
	}

	infoPath := filepath.Join("./data", "info.json")

	// Load existing entries.
	var infos []pluginMeta
	if raw, err := os.ReadFile(infoPath); err == nil {
		_ = json.Unmarshal(raw, &infos)
	}

	// Upsert: replace entry with the same filename if it already exists.
	meta := pluginMeta{
		Name:        c.PostForm("name"),
		Description: c.PostForm("description"),
		Service:     c.PostForm("service"),
		Filename:    file.Filename,
	}
	updated := false
	for i, m := range infos {
		if m.Filename == meta.Filename {
			infos[i] = meta
			updated = true
			break
		}
	}
	if !updated {
		infos = append(infos, meta)
	}

	if encoded, err := json.MarshalIndent(infos, "", "  "); err == nil {
		if err := os.WriteFile(infoPath, encoded, 0644); err != nil {
			log.Printf("failed to write data/info.json: %v", err)
		}
	}

	c.JSON(http.StatusOK, gin.H{"message": "uploaded successfully", "plugin": file.Filename})
}

// startWebServer configures and starts the HTTP server in a background
// goroutine. It returns the *http.Server so the caller can shut it down
// gracefully when ready.
func startWebServer() *http.Server {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()

	api := r.Group("/api")
	{
		api.GET("/plugins", listPlugins)
		api.POST("/plugins/:name", runPlugin)
		api.POST("/upload", uploadPlugin)
		api.GET("/events", listEvents)
	}

	// Serve the embedded public directory for all unmatched routes so that
	// the /api prefix registered above is not shadowed by a catch-all wildcard.
	publicFS, err := fs.Sub(staticFiles, "public")
	if err != nil {
		log.Fatalf("failed to create sub filesystem: %v", err)
	}
	r.NoRoute(gin.WrapH(http.FileServer(http.FS(publicFS))))

	srv := &http.Server{
		Addr:    ":8080",
		Handler: r,
	}

	go func() {
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("failed to run server: %v", err)
		}
	}()
	log.Println("server listening on :8080")

	return srv
}
