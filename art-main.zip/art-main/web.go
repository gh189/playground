package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"sync"
	"syscall"
	"time"

	hclog "github.com/hashicorp/go-hclog"
	goplugin "github.com/hashicorp/go-plugin"

	"github.com/gin-gonic/gin"

	"art/shared"
)

// Event records a single occurrence captured by the framework.
type Event struct {
	ID        int       `json:"id"`
	Timestamp time.Time `json:"timestamp"`
	Plugin    string    `json:"plugin"`
	Details   string    `json:"details"`
}

// events is the in-memory event log, protected by eventsMu.
// nextEventID is the auto-increment counter for Event.ID.
var (
	events      []Event
	eventsMu    sync.Mutex
	nextEventID int = 1
)

// listEvents returns all recorded events as a JSON array.
func listEvents(c *gin.Context) {
	eventsMu.Lock()
	snapshot := make([]Event, len(events))
	copy(snapshot, events)
	eventsMu.Unlock()

	c.JSON(http.StatusOK, snapshot)
}

// listPlugins scans the ./bin directory and returns each regular file (binary plugin).
func listPlugins(c *gin.Context) {
	entries, err := os.ReadDir("./bin")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to read bin directory"})
		return
	}

	type pluginInfo struct {
		Name string `json:"name"`
	}

	plugins := make([]pluginInfo, 0)
	for _, e := range entries {
		if !e.IsDir() && e.Name() != ".DS_Store" {
			plugins = append(plugins, pluginInfo{Name: e.Name()})
		}
	}

	c.JSON(http.StatusOK, gin.H{"plugins": plugins})
}

// runPlugin launches the named binary plugin from ./bin, calls Runner.Run, and
// returns the result as JSON.
func runPlugin(c *gin.Context) {
	name := c.Param("name")
	pluginPath := filepath.Join("./bin", name)

	if _, err := os.Stat(pluginPath); os.IsNotExist(err) {
		c.JSON(http.StatusNotFound, gin.H{"error": fmt.Sprintf("plugin %q not found in ./bin", name)})
		return
	}

	client := goplugin.NewClient(&goplugin.ClientConfig{
		HandshakeConfig: shared.Handshake,
		Plugins:         shared.PluginMap,
		Cmd:             exec.Command(pluginPath),
		AllowedProtocols: []goplugin.Protocol{
			goplugin.ProtocolNetRPC,
		},
		Logger: hclog.New(&hclog.LoggerOptions{
			Level:  hclog.Warn,
			Output: os.Stderr,
		}),
	})
	defer client.Kill()

	rpcClient, err := client.Client()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("plugin client error: %v", err)})
		return
	}

	raw, err := rpcClient.Dispense("runner")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("dispense error: %v", err)})
		return
	}

	runner := raw.(shared.Runner)
	beforeMsg, err := runner.BeforeTest(name)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("before_test error: %v", err)})
		return
	}

	msg, err := runner.Run(name)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("run error: %v", err)})
		return
	}

	c.JSON(http.StatusOK, gin.H{"plugin": name, "before_test": beforeMsg, "result": msg})

	eventsMu.Lock()
	ev := Event{ID: nextEventID, Timestamp: time.Now(), Plugin: name, Details: msg}
	events = append(events, ev)
	nextEventID++
	eventsMu.Unlock()

	// Save event details as a PNG image.
	imgText := fmt.Sprintf("ID: %d\nTimestamp: %s\nPlugin: %s\nDetails: %s",
		ev.ID, ev.Timestamp.Format(time.RFC3339), ev.Plugin, ev.Details)
	imgPath := fmt.Sprintf("data/event-%d.png", ev.ID)
	if err := GenerateTextImage(imgText, imgPath); err != nil {
		log.Printf("failed to save event image: %v", err)
	}
}

// uploadPlugin accepts a multipart file upload and saves it to ./bin.
func uploadPlugin(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": fmt.Sprintf("failed to get file: %v", err)})
		return
	}

	dst := filepath.Join("./bin", file.Filename)
	if err := c.SaveUploadedFile(file, dst); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("failed to save file: %v", err)})
		return
	}

	// Make the uploaded binary executable.
	if err := os.Chmod(dst, 0755); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("failed to chmod file: %v", err)})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "uploaded successfully", "plugin": file.Filename})
}

func startWebServer() {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()

	api := r.Group("/api")
	{
		api.GET("/plugins", listPlugins)
		api.POST("/plugins/:name", runPlugin)
		api.POST("/upload", uploadPlugin)
		api.GET("/events", listEvents)
	}

	// Serve the public directory for all unmatched routes so that the /api
	// prefix registered above is not shadowed by a catch-all wildcard.
	r.NoRoute(gin.WrapH(http.FileServer(http.Dir("./public"))))

	srv := &http.Server{
		Addr:    ":8080",
		Handler: r,
	}

	// Start the server in a background goroutine so the main goroutine
	// can block on the quit signal instead.
	go func() {
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("failed to run server: %v", err)
		}
	}()
	log.Println("server listening on :8080")

	// Block until SIGINT or SIGTERM is received.
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("shutting down server...")

	// Give in-flight requests up to 5 seconds to complete.
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.Fatalf("server forced to shutdown: %v", err)
	}
	log.Println("server stopped")
}
