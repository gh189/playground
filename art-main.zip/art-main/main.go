package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"
)

// db is the application-wide Postgres connection pool.
var db = &PG{
	Username: "app",
	Password: "secret",
	Host:     "10.0.1.6",
	Port:     5432,
	Database: "art",
}

func main() {
	// init
	if err := EnsureDir(binPath("data")); err != nil {
		log.Fatalf("failed to create data directory: %v", err)
	}
	if err := EnsureDir(binPath("data/plugins")); err != nil {
		log.Fatalf("failed to create data/plugins directory: %v", err)
	}
	if err := EnsureDir(binPath("data/images")); err != nil {
		log.Fatalf("failed to create data/images directory: %v", err)
	}
	if err := EnsureDir(binPath("data/logs")); err != nil {
		log.Fatalf("failed to create data/logs directory: %v", err)
	}

	// Wait (without blocking startup) until Postgres connection details have
	// been populated, then ensure the plugins/events tables exist.
	go func() {
		ticker := time.NewTicker(10000 * time.Millisecond)
		defer ticker.Stop()
		for db.Host == "" {
			log.Print("waiting for Postgres connection details...")
			<-ticker.C
		}

		if _, err := db.Exec(context.Background(), SQLCreatePluginsTable); err != nil {
			log.Printf("failed to create plugins table: %v", err)
			return
		}
		if _, err := db.Exec(context.Background(), SQLCreateEventsTable); err != nil {
			log.Printf("failed to create events table: %v", err)
			return
		}

		// Extract all plugin binaries from the database and overwrite any
		// existing copies in data/plugins so disk state matches the DB.
		if err := SyncPluginsFromDB(context.Background()); err != nil {
			log.Printf("failed to sync plugins from database: %v", err)
		}
	}()

	c := startScheduler()
	defer c.Stop()

	// Request PostgreSQL secrets from the PG maker service every minute.
	if _, err := c.AddFunc("@every 1m", func() {
		if err := RequestPGSecrets(dbName, selfURL+"/api/pgmaker"); err != nil {
			log.Printf("RequestPGSecrets failed: %v", err)
		}
	}); err != nil {
		log.Fatalf("failed to register RequestPGSecrets job: %v", err)
	}

	srv := startWebServer()

	log.Println("Started.")

	// Block until SIGINT or SIGTERM is received.
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("shutting down...")

	// Give in-flight requests up to 5 seconds to complete.
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.Fatalf("server forced to shutdown: %v", err)
	}
	log.Println("stopped.")
}
