#!/usr/bin/env bash
set -euo pipefail

HEALTH_URL="http://localhost:8080/api/pgmaker/health"

http_status=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL")

if [ "$http_status" -eq 200 ]; then
  echo "Health check passed: ${HEALTH_URL} returned HTTP 200."
elif [ "$http_status" -eq 500 ]; then
  echo "Health check failed: ${HEALTH_URL} returned HTTP 500. Exiting." >&2
  exit 1
else
  echo "Health check returned unexpected status: HTTP ${http_status}." >&2
  exit 1
fi
