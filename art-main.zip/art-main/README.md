# A.R.T
```
   █████╗     ██████╗    ████████╗
  ██╔══██╗    ██╔══██╗   ╚══██╔══╝
  ███████║    ██████╔╝      ██║   
  ██╔══██║    ██╔══██╗      ██║   
  ██║  ██║    ██║  ██║      ██║   
  ╚═╝  ╚═╝    ╚═╝  ╚═╝      ╚═╝   

  A . R . T  —  Automated Regression Testing
  ───────────────────────────────────────────
```

A.R.T is a lightweight, plugin-driven automated regression testing framework. Plugins are standalone Go binaries loaded at runtime via [hashicorp/go-plugin](https://github.com/hashicorp/go-plugin) (net/rpc). A built-in web UI lets you discover, upload, and trigger plugins from a browser without touching the CLI. Every plugin run is recorded as an event (in-memory + PNG snapshot) and surfaced in the **History** table.

---

## Build

Build the main application and any plugin binaries separately:

```bash
# Build the demo plugin binary
go build -o bin/demo-plugin ./plugins/demo

# Build the main application
go build -o bin/art .
```

Or build everything at once:

```bash
go build ./...
```

---

## Run

```bash
# Run directly (recommended during development)
go run .

# Or run the pre-built binary
./bin/art
```

The server starts on **http://localhost:8080** by default.  
A background cron scheduler also starts and scans for pending jobs every minute.

---

## REST API

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/plugins` | List all plugins with full metadata from `data/info.json` |
| `POST` | `/api/plugins/:name` | Run the named plugin and return step-level results |
| `POST` | `/api/upload` | Upload a plugin binary to `./data/uploads` (multipart form) |
| `GET` | `/api/events` | Return all recorded run events |

### Examples

```bash
# List available plugins (returns full metadata)
curl http://localhost:8080/api/plugins
# → [{"name":"Demo Plugin","description":"A demo plugin","service":"demo","filename":"demo-plugin"}]

# Run a plugin (returns per-step results)
curl -X POST http://localhost:8080/api/plugins/demo-plugin
# → {
#     "before_test": "BeforeTest called (from plugin). Timeout: 10",
#     "plugin": "demo-plugin",
#     "steps": [
#       {"name":"hello","start_time":"...","end_time":"...","success":true,"output":"Hello from plugin!"},
#       {"name":"exec","start_time":"...","end_time":"...","success":false,"output":"Execution failed (simulated error)"}
#     ],
#     "result": "1/2 steps passed"
#   }

# Upload a plugin binary with metadata
curl -X POST http://localhost:8080/api/upload \
  -F "file=@./bin/my-plugin" \
  -F "name=My Plugin" \
  -F "description=Does something useful" \
  -F "service=my-service"
# → {"message":"uploaded successfully","plugin":"my-plugin"}

# List run history
curl http://localhost:8080/api/events
# → [{"id":1,"timestamp":"...","plugin":"demo-plugin","details":"1/2 steps passed","steps":[...],"success":false}]
```

---

## Web UI

Opening **http://localhost:8080** in a browser shows the A.R.T dashboard.

- **Upload** — fill in the plugin **Name**, **Description**, and **Service** fields, then pick a compiled binary and click **⬆ Upload**. The binary is saved to `./data/uploads` (created automatically on first upload), made executable, and metadata is persisted to `data/info.json`.
- **Plugins** — one card per plugin entry in `data/info.json`. Each card has a **▶ Run** button that POSTs to `/api/plugins/:name` and shows the outcome inline (✓ Done / ✗ Failed). Cards also reflect the latest execution state: green border for a fully-passing run, red for any failure. Click a card to open a detail modal showing name, description, service, and binary filename.
- **History** — a live table of every plugin run, showing timestamp, plugin name, overall success, and step count. Click **Details** on any row to open a modal with the full step-level breakdown (step name, start time, duration, status, and output).

Each completed run also generates a PNG snapshot (`data/event-<id>.png`) that embeds the event summary alongside the pass/fail badge from `misc/passed.png`.

---

## Writing a Plugin

1. Create a new package under `plugins/<your-plugin>/main.go`.
2. Implement the `shared.Runner` interface:
   ```go
   type Runner interface {
       // BeforeTest is called before Run; use it for setup or precondition checks.
       BeforeTest(ctx RunContext) (string, error)
       // Run executes the main test logic and returns a slice of Steps.
       Run(ctx RunContext) ([]Step, error)
   }
   ```
   `RunContext` carries runtime configuration passed by the host:
   ```go
   type RunContext struct {
       Timeout int `json:"timeout"`
   }
   ```
   Each `Step` describes one execution unit:
   ```go
   type Step struct {
       Name      string    `json:"name"`
       StartTime time.Time `json:"start_time"`
       EndTime   time.Time `json:"end_time"`
       Success   bool      `json:"success"`
       Output    string    `json:"output"`
   }
   ```
3. Serve it with `go-plugin`:
   ```go
   func main() {
       impl := &yourImpl{}
       goplugin.Serve(&goplugin.ServeConfig{
           HandshakeConfig: shared.Handshake,
           Plugins: map[string]goplugin.Plugin{
               "runner": &shared.RunnerPlugin{Impl: impl},
           },
       })
   }
   ```
4. Build the binary:
   ```bash
   go build -o bin/<your-plugin> ./plugins/<your-plugin>
   ```
5. Refresh the web UI — upload the binary from `./bin/<your-plugin>` through the **Upload** section (add a name, description, and service). The binary is saved to `./data/uploads` and the new plugin card appears automatically.

---

## Project Structure

```
.
├── main.go               # Entry point — starts scheduler and web server, handles graceful shutdown
├── web.go                # Gin HTTP server, REST API handlers & event log
├── scheduler.go          # Cron scheduler — scans for pending jobs every minute
├── utils.go              # GenerateTextImage — renders event summary PNGs
├── go.mod                # Go module definition (module: art)
├── go.sum                # Dependency checksums
├── plugins/
│   └── demo/
│       └── main.go       # Demo plugin — implements BeforeTest and Run (returns []Step)
├── shared/
│   └── interface.go      # Runner interface, Step type, RPC wrappers & handshake config
├── data/
│   ├── info.json         # Plugin metadata store (name, description, service, filename)
│   ├── uploads/          # Uploaded plugin binaries (auto-created on first upload)
│   └── event-<n>.png     # Auto-generated PNG snapshot for each plugin run
├── public/               # Static web assets served by Gin
│   ├── index.html        # Dashboard — upload, plugin cards, run history table & modals
│   ├── css/
│   │   └── index.css     # Stylesheet
│   ├── js/
│   │   ├── jquery-4.0.0.min.js
│   │   └── index.js      # Fetches /api/plugins & /api/events, wires Upload/Run/modals
│   └── images/
│       ├── favicon.png
│       └── logo.png
├── misc/                 # Design / branding assets (not served)
│   ├── avatar.svg
│   ├── avatar-s.svg
│   ├── logo.svg
│   ├── passed.png        # Badge overlaid on event PNG snapshots
│   └── passed.svg
└── bin/                  # Compiled plugin binaries (git-ignored)
    └── demo-plugin       # Demo plugin binary
```
