# A.R.T
```
   █████╗     ██████╗    ████████╗
  ██╔══██╗    ██╔══██╗   ╚══██╔══╝
  ███████║    ██████╔╝      ██║   
  ██╔══██║    ██╔══██╗      ██║   
  ██║  ██║    ██║  ██║      ██║   
  ╚═╝  ╚═╝    ╚═╝  ╚═╝      ╚═╝   

  A . R . T  —  Automated Regression Testing
  ───────────────────────────────────────────
```

A.R.T is a lightweight, plugin-driven automated regression testing framework. Plugins are standalone Go binaries loaded at runtime via [hashicorp/go-plugin](https://github.com/hashicorp/go-plugin) (net/rpc). A built-in web UI lets you discover, upload, and trigger plugins from a browser without touching the CLI.

---

## Build

Build the main application and any plugin binaries separately:

```bash
# Build the demo plugin binary
go build -o bin/demo-plugin ./plugins/demo

# Build the main application
go build -o bin/art .
```

Or build everything at once:

```bash
go build ./...
```

---

## Run

```bash
# Run directly (recommended during development)
go run .

# Or run the pre-built binary
./bin/art
```

The server starts on **http://localhost:8080** by default.

---

## REST API

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/plugins` | List all plugin binaries found in `./bin` |
| `POST` | `/api/plugins/:name` | Run the named plugin and return its result |
| `POST` | `/api/upload` | Upload a plugin binary to `./bin` (multipart `file` field) |

### Examples

```bash
# List available plugins
curl http://localhost:8080/api/plugins
# → {"plugins":[{"name":"demo-plugin"}]}

# Run a plugin
curl -X POST http://localhost:8080/api/plugins/demo-plugin
# → {"before_test":"BeforeTest called for demo-plugin (from plugin)","plugin":"demo-plugin","result":"Hello, demo-plugin! (from plugin)"}

# Upload a plugin binary
curl -X POST http://localhost:8080/api/upload -F "file=@./bin/my-plugin"
# → {"message":"uploaded successfully","plugin":"my-plugin"}
```

---

## Web UI

Opening **http://localhost:8080** in a browser shows the A.R.T dashboard.

- **Upload Plugin** — drag a compiled plugin binary onto the file picker and click **⬆ Upload**. The binary is saved to `./bin`, made executable, and the plugin list refreshes automatically.
- **Plugins** — one card per binary discovered in `./bin`. Each card has a **▶ Run** button that POSTs to `/api/plugins/:name` and shows the outcome inline (✓ Done / ✗ Failed).
- **Run History** — reserved for upcoming run history tracking.

---

## Writing a Plugin

1. Create a new package under `plugins/<your-plugin>/main.go`.
2. Implement the `shared.Runner` interface:
   ```go
   type Runner interface {
       // BeforeTest is called before Run; use it for setup or precondition checks.
       BeforeTest(name string) (string, error)
       // Run executes the main test logic.
       Run(name string) (string, error)
   }
   ```
3. Serve it with `go-plugin`:
   ```go
   func main() {
       goplugin.Serve(&goplugin.ServeConfig{
           HandshakeConfig: shared.Handshake,
           Plugins: map[string]goplugin.Plugin{
               "runner": &shared.RunnerPlugin{Impl: &yourImpl{}},
           },
       })
   }
   ```
4. Build the binary into `./bin`:
   ```bash
   go build -o bin/<your-plugin> ./plugins/<your-plugin>
   ```
5. Refresh the web UI — the new plugin card appears automatically.  
   Alternatively, upload the binary directly through the **Upload Plugin** section.

---

## Project Structure

```
.
├── main.go               # Entry point — starts the web server
├── web.go                # Gin HTTP server, REST API handlers & graceful shutdown
├── go.mod                # Go module definition (module: art)
├── go.sum                # Dependency checksums
├── plugins/
│   └── demo/
│       └── main.go       # Demo plugin — implements BeforeTest and Run
├── shared/
│   └── interface.go      # Runner interface, RPC client/server wrappers & handshake config
├── public/               # Static web assets served by Gin
│   ├── index.html        # Dashboard — upload plugins, view plugin cards, run history
│   ├── css/
│   │   └── index.css     # Stylesheet
│   ├── js/
│   │   ├── jquery-4.0.0.min.js
│   │   └── index.js      # Fetches /api/plugins, wires up Upload and Run buttons
│   └── images/
│       ├── favicon.png
│       └── logo.png
├── misc/                 # Design / branding assets (not served)
│   ├── avatar.svg
│   ├── avatar-s.svg
│   └── logo.svg
└── bin/                  # Compiled plugin binaries (git-ignored)
    └── demo-plugin       # Demo plugin binary
```
