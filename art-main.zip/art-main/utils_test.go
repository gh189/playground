package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestEnsureDir(t *testing.T) {
	t.Run("creates new directory", func(t *testing.T) {
		dir := filepath.Join(t.TempDir(), "newdir")
		if err := EnsureDir(dir); err != nil {
			t.Fatalf("EnsureDir(%q) returned error: %v", dir, err)
		}
		if _, err := os.Stat(dir); os.IsNotExist(err) {
			t.Errorf("directory %q was not created", dir)
		}
	})

	t.Run("creates nested directories", func(t *testing.T) {
		dir := filepath.Join(t.TempDir(), "a", "b", "c")
		if err := EnsureDir(dir); err != nil {
			t.Fatalf("EnsureDir(%q) returned error: %v", dir, err)
		}
		if _, err := os.Stat(dir); os.IsNotExist(err) {
			t.Errorf("nested directory %q was not created", dir)
		}
	})

	t.Run("succeeds if directory already exists", func(t *testing.T) {
		dir := t.TempDir()
		if err := EnsureDir(dir); err != nil {
			t.Fatalf("EnsureDir on existing dir returned error: %v", err)
		}
	})
}
