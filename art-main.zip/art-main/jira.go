package main

import (
	"fmt"

	"github.com/go-resty/resty/v2"
)

type Jira struct {
	Username string
	Password string
}

// AttachFile uploads the file at attachmentPath as an attachment on the Jira
// ticket identified by issueKey (e.g. "DSJIRACONF-5539"), authenticating with
// j.Username/j.Password. It mirrors:
//
//	curl -D- \
//	  -u <username>:<password> \
//	  -H "X-Atlassian-Token: nocheck" \
//	  -F "file=@<attachmentPath>" \
//	  -X POST "<jiraURL>/rest/api/2/issue/<issueKey>/attachments"
//
// It returns an error if the request fails or Jira responds with a non-2xx
// status.
func (j *Jira) AttachFile(issueKey, attachmentPath string) error {
	resp, err := resty.New().R().
		SetBasicAuth(j.Username, j.Password).
		SetHeader("X-Atlassian-Token", "nocheck").
		SetFile("file", attachmentPath).
		Post(fmt.Sprintf("%s/rest/api/2/issue/%s/attachments", jiraURL, issueKey))
	if err != nil {
		return fmt.Errorf("AttachFile: %w", err)
	}
	if resp.IsError() {
		return fmt.Errorf("AttachFile: failed to attach file to %s: %d: %s", issueKey, resp.StatusCode(), resp.String())
	}
	return nil
}
