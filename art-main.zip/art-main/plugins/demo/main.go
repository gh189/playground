package main

import (
	"errors"
	"os"
	"time"

	hclog "github.com/hashicorp/go-hclog"
	goplugin "github.com/hashicorp/go-plugin"

	"art/shared"
)

// runnerImpl is the real implementation running inside the plugin process.
type runnerImpl struct {
	logger hclog.Logger
}

func (r *runnerImpl) Run(ctx shared.RunContext) ([]shared.Step, error) {
	r.logger.Debug("Run called", "timeout", ctx.Timeout)
	now := time.Now()
	steps := []shared.Step{
		{
			Name:      "hello",
			StartTime: now,
			EndTime:   now,
			Success:   true,
			Output:    "Hello from plugin!",
		},
		//{
		//	Name:      "exec",
		//	StartTime: now,
		//	EndTime:   now,
		//	Success:   false,
		//	Output:    "Execution failed (simulated error)",
		//},
	}
	r.logger.Info("Run completed", "steps", len(steps))
	return steps, nil
}

func (r *runnerImpl) BeforeTest(ctx shared.RunContext) (string, error) {
	r.logger.Debug("BeforeTest called", "timeout", ctx.Timeout)
	return "Error simulation", errors.New("Error simulation")
	//return "BeforeTest called (from plugin). Timeout: " + fmt.Sprintf("%d", ctx.Timeout), nil
}

func main() {
	// logger writes hclog-formatted (JSON) entries to stderr. The host
	// process's go-plugin client reads this stream, parses each entry, and
	// re-emits it through its own logger (see runPluginBinary in web.go),
	// which routes it into a per-plugin log file. This is what allows
	// plugin logs to be captured server-side.
	logger := hclog.New(&hclog.LoggerOptions{
		Name:       "demo-plugin",
		Level:      hclog.Trace,
		Output:     os.Stderr,
		JSONFormat: true,
	})

	impl := &runnerImpl{logger: logger}
	goplugin.Serve(&goplugin.ServeConfig{
		HandshakeConfig: shared.Handshake,
		Plugins: map[string]goplugin.Plugin{
			"runner": &shared.RunnerPlugin{Impl: impl},
		},
		Logger: logger,
	})
}
