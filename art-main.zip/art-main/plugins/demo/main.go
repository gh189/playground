package main

import (
	"fmt"
	"time"

	goplugin "github.com/hashicorp/go-plugin"

	"art/shared"
)

// runnerImpl is the real implementation running inside the plugin process.
type runnerImpl struct{}

func (r *runnerImpl) Run(ctx shared.RunContext) ([]shared.Step, error) {
	now := time.Now()
	steps := []shared.Step{
		{
			Name:      "hello",
			StartTime: now,
			EndTime:   now,
			Success:   true,
			Output:    "Hello from plugin!",
		},
		//{
		//	Name:      "exec",
		//	StartTime: now,
		//	EndTime:   now,
		//	Success:   false,
		//	Output:    "Execution failed (simulated error)",
		//},
	}
	return steps, nil
}

func (r *runnerImpl) BeforeTest(ctx shared.RunContext) (string, error) {
	return "BeforeTest called (from plugin). Timeout: " + fmt.Sprintf("%d", ctx.Timeout), nil
}

func main() {
	impl := &runnerImpl{}
	goplugin.Serve(&goplugin.ServeConfig{
		HandshakeConfig: shared.Handshake,
		Plugins: map[string]goplugin.Plugin{
			"runner": &shared.RunnerPlugin{Impl: impl},
		},
	})
}
