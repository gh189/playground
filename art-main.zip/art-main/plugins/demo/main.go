package main

import (
	"fmt"

	goplugin "github.com/hashicorp/go-plugin"

	"art/shared"
)

// runnerImpl is the real implementation running inside the plugin process.
type runnerImpl struct{}

func (r *runnerImpl) Run(name string) (string, error) {
	return fmt.Sprintf("Hello, %s! (from plugin)", name), nil
}

func (r *runnerImpl) BeforeTest(name string) (string, error) {
	return fmt.Sprintf("BeforeTest called for %s (from plugin)", name), nil
}

func main() {
	impl := &runnerImpl{}
	goplugin.Serve(&goplugin.ServeConfig{
		HandshakeConfig: shared.Handshake,
		Plugins: map[string]goplugin.Plugin{
			"runner": &shared.RunnerPlugin{Impl: impl},
		},
	})
}
