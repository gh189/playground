package main

import (
	"time"

	goplugin "github.com/hashicorp/go-plugin"

	"art/shared"
)

// runnerImpl is the real implementation running inside the plugin process.
type runnerImpl struct{}

func (r *runnerImpl) Run(name string) ([]shared.Step, error) {
	now := time.Now()
	steps := []shared.Step{
		{
			Name:      "hello",
			StartTime: now,
			EndTime:   now,
			Success:   true,
			Output:    "Hello from " + name + "!",
		},
		//{
		//	Name:      "exec",
		//	StartTime: now,
		//	EndTime:   now,
		//	Success:   false,
		//	Output:    "Execution failed for " + name + " (simulated error)",
		//},
	}
	return steps, nil
}

func (r *runnerImpl) BeforeTest(name string) (string, error) {
	return "BeforeTest called for " + name + " (from plugin)", nil
}

func main() {
	impl := &runnerImpl{}
	goplugin.Serve(&goplugin.ServeConfig{
		HandshakeConfig: shared.Handshake,
		Plugins: map[string]goplugin.Plugin{
			"runner": &shared.RunnerPlugin{Impl: impl},
		},
	})
}
