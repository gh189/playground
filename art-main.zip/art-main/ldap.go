package main

import (
	"fmt"

	ldap "github.com/go-ldap/ldap/v3"
)

const (
	ldapURL      = "ldap://10.0.1.8:389"
	ldapBaseDN   = "cn=users,dc=lab,dc=local"
	ldapUserAttr = "uid" // use "sAMAccountName" for Active Directory
)

// LDAPAuthUser authenticates a user against the LDAP server via simple bind.
// Returns true on success, false on failure.
func LDAPAuthUser(username, password string) bool {
	conn, err := ldap.DialURL(ldapURL)
	if err != nil {
		return false
	}
	defer conn.Close()

	bindDN := fmt.Sprintf("%s=%s,%s", ldapUserAttr, ldap.EscapeFilter(username), ldapBaseDN)
	return conn.Bind(bindDN, password) == nil
}
