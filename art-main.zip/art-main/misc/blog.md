# Introducing A.R.T. — Automated Regression Testing

![A.R.T Avatar](avatar.svg)

Modern software teams need regression testing that's fast to extend, easy to observe, and doesn't require redeploying the whole application every time a new test suite is added. **A.R.T** (Automated Regression Testing) is a lightweight, plugin-driven framework built in Go that addresses exactly that.

---

## What Is A.R.T?

A.R.T is a self-hosted testing platform with three core responsibilities:

1. **Load and execute test plugins** — compiled Go binaries that define their own test logic.
2. **Record every run** — persisting results to PostgreSQL and generating a PNG snapshot for each event.
3. **Surface everything through a web UI and REST API** — so any team member can trigger, inspect, and upload plugins without touching the CLI.

---

## Key Features

### 🔌 Plugin-Driven Architecture
Test suites are standalone Go binaries, not baked into the host application. You write a plugin, compile it, upload it, and A.R.T runs it on demand. Adding a new suite is a file upload — no redeployment, no restarts.

### 🌐 Built-in Web Dashboard
Navigate to `http://localhost:8080` to:
- **Upload** a new plugin binary with a name, description, and service tag.
- **Run** any registered plugin with a single click — results appear inline.
- **Browse History** — every past run is listed in a table with timestamps, pass/fail status, and step-level details.

### 📋 Step-Level Reporting
Each plugin reports granular `Step` results: name, start time, end time, success flag, and raw output. The dashboard drill-down shows exactly which step passed and which failed, down to the millisecond.

### 🗓️ Background Scheduler
A cron-based scheduler runs every minute to scan for pending jobs, enabling future support for fully automated, unattended regression runs.

### 🖼️ PNG Snapshots
Every completed run generates an image (`data/images/event-<id>.png`) that embeds the event summary alongside a pass/fail badge — useful for embedding results in reports, chat notifications, or tickets.

### 🗄️ PostgreSQL-Backed Persistence
Plugin metadata and run events are stored in Postgres, giving you a durable, queryable history of all test activity.

---

## Architecture

![A.R.T Architecture](architecture.svg)

The host and every plugin share a `Runner` interface defined in `shared/interface.go`. Communication happens over **net/rpc**, brokered by [hashicorp/go-plugin](https://github.com/hashicorp/go-plugin). A magic-cookie handshake (`ART_PLUGIN=runner`) prevents accidentally running incompatible binaries.

---

## How It Works

### 1. The `Runner` Interface

Every plugin implements two methods:

```go
type Runner interface {
    // BeforeTest is called first — use it for setup or precondition checks.
    BeforeTest(ctx RunContext) (string, error)
    // Run executes the main test logic and returns per-step results.
    Run(ctx RunContext) ([]Step, error)
}
```

`RunContext` carries runtime configuration (e.g., `Timeout`), and each `Step` records its own timing and outcome.

### 2. Plugin Registration

When an authorized admin uploads a binary via the web UI, A.R.T:
- Saves the binary to `data/plugins/` and marks it executable.
- Upserts its metadata (name, description, service) *and* the binary itself into the `plugins` table in Postgres.

The plugin card appears on the dashboard immediately — no restart needed — and because the binary lives in the database too, it's automatically restored to disk on any host that starts up and calls `SyncPluginsFromDB`.

### 3. Running a Plugin

Hitting **▶ Run** (or `POST /api/plugins/:name`) causes the host to:
1. Launch the plugin binary as a subprocess via `go-plugin`.
2. Call `BeforeTest()` for setup.
3. Call `Run()` and collect `[]Step` results.
4. Persist the event to Postgres and generate a PNG snapshot.
5. Return the step-level JSON to the caller.

### 4. Browsing History

`GET /api/events` returns all recorded runs. The History table in the UI lets you click **Details** on any row to see the full step breakdown.

---

## Writing Your First Plugin

```go
package main

import (
    goplugin "github.com/hashicorp/go-plugin"
    "art/shared"
    "time"
)

type MyPlugin struct{}

func (p *MyPlugin) BeforeTest(ctx shared.RunContext) (string, error) {
    return "setup complete", nil
}

func (p *MyPlugin) Run(ctx shared.RunContext) ([]shared.Step, error) {
    start := time.Now()
    // ... your test logic ...
    return []shared.Step{
        {Name: "check-api", StartTime: start, EndTime: time.Now(), Success: true, Output: "200 OK"},
    }, nil
}

func main() {
    goplugin.Serve(&goplugin.ServeConfig{
        HandshakeConfig: shared.Handshake,
        Plugins: map[string]goplugin.Plugin{
            "runner": &shared.RunnerPlugin{Impl: &MyPlugin{}},
        },
    })
}
```

Build it, upload it, click **▶ Run** — that's it.

---

## Project Structure

```
art/
├── main.go          # Entry point — scheduler + web server + graceful shutdown
├── web.go           # Gin HTTP server, REST handlers, event log
├── scheduler.go     # Cron scheduler (every minute)
├── pg.go            # PostgreSQL connection and schema
├── utils.go         # PNG snapshot generation
├── shared/
│   └── interface.go # Runner interface, Step type, RPC wrappers, handshake
├── plugins/
│   └── demo/        # Reference plugin implementation
└── public/          # Static web assets (HTML, CSS, JS)
```

---

## Getting Started

```bash
# Build the demo plugin
go build -o bin/demo-plugin ./plugins/demo

# Run the server
go run .
# → http://localhost:8080
```

Upload the binary from the web UI, click **▶ Run**, and watch the results roll in.

---

A.R.T keeps the testing infrastructure thin and the plugin contract simple. If your test logic can be expressed as a Go binary that returns a slice of `Step`s, it belongs in A.R.T.

---

## What's New

Since the initial release, A.R.T has picked up authentication, hardened persistence, and better observability:

### 🔐 LDAP Login + JWT Sessions
The dashboard now has a real login flow. `POST /api/login` authenticates against an LDAP server (`ldap.go`) and, on success, issues an RS256-signed JWT stored in an HTTP-only `jwt` cookie. `GET /api/login` reports the current session's status and claims, and `POST /api/logout` clears the cookie. The JWT payload carries the user's `id`, replacing the earlier subject-based claim.

### 🛡️ Admin-Gated Uploads
Not every logged-in user should be able to push new plugin binaries. A new `AdminIDs` list in `constants.go` defines who's authorized, and a `requireAdmin` middleware in `web.go` enforces it on `POST /api/upload`: unauthenticated or non-admin requests are rejected with `401 Unauthorized`, and the web UI now surfaces a friendly "you're not allowed to upload" message instead of a raw error.

### 🗄️ Database as the Source of Truth for Plugins
Plugin binaries are now stored directly in Postgres (`plugin_binary` column) rather than relying solely on `data/plugins/` on disk. On startup, `SyncPluginsFromDB` pulls every stored binary back down to disk (marking it executable), so a redeployed or freshly-provisioned host reconstructs its full plugin set automatically.

### 🗓️ Scheduler Runs Every Plugin, Every 3 Hours
The cron scheduler moved from a placeholder minute-tick to a real job: `runAllPlugins` scans `data/plugins`, executes each binary via the shared `runPluginBinary` helper, and persists results (including failures) to the `events` table. The interval was tuned from every minute to every 3 hours to match real-world regression cadence.

### 📄 Per-Plugin Log Files
Each plugin run now captures its `go-hclog` output into a dedicated file at `data/logs/<plugin>.log` instead of mixing everything into the host's stderr. A new `GET /api/logs/:plugin_name` endpoint (with a matching "Logs" button on each plugin card) lets you inspect a plugin's execution history straight from the dashboard.

### 🔌 Dynamic PG Secrets & Self-URL
Connecting to Postgres no longer requires hardcoded credentials. `RequestPGSecrets` polls a PG-maker service every minute for fresh connection details, and both the PG-maker endpoint and the host's own callback URL (`selfURL`) now resolve dynamically based on the `ENV` environment variable (local / `uat-1` / `prd`), making the same binary deployable across environments without code changes.

### 👤 Developer Info & Polish
The dashboard's info modal now includes a developer contact section with a Teams shortcut icon, making it easier to reach the maintainer directly from the UI.

These changes push A.R.T closer to a production-ready internal tool: authenticated access, durable plugin storage, environment-aware configuration, and per-plugin observability — all while keeping the original "upload a binary, click run" workflow intact.
