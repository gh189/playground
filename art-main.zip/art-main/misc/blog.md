# Introducing A.R.T — Automated Regression Testing

```
   █████╗     ██████╗    ████████╗
  ██╔══██╗    ██╔══██╗   ╚══██╔══╝
  ███████║    ██████╔╝      ██║
  ██╔══██║    ██╔══██╗      ██║
  ██║  ██║    ██║  ██║      ██║
  ╚═╝  ╚═╝    ╚═╝  ╚═╝      ╚═╝
```

Modern software teams need regression testing that's fast to extend, easy to observe, and doesn't require redeploying the whole application every time a new test suite is added. **A.R.T** (Automated Regression Testing) is a lightweight, plugin-driven framework built in Go that addresses exactly that.

---

## What Is A.R.T?

A.R.T is a self-hosted testing platform with three core responsibilities:

1. **Load and execute test plugins** — compiled Go binaries that define their own test logic.
2. **Record every run** — persisting results to PostgreSQL and generating a PNG snapshot for each event.
3. **Surface everything through a web UI and REST API** — so any team member can trigger, inspect, and upload plugins without touching the CLI.

---

## Key Features

### 🔌 Plugin-Driven Architecture
Test suites are standalone Go binaries, not baked into the host application. You write a plugin, compile it, upload it, and A.R.T runs it on demand. Adding a new suite is a file upload — no redeployment, no restarts.

### 🌐 Built-in Web Dashboard
Navigate to `http://localhost:8080` to:
- **Upload** a new plugin binary with a name, description, and service tag.
- **Run** any registered plugin with a single click — results appear inline.
- **Browse History** — every past run is listed in a table with timestamps, pass/fail status, and step-level details.

### 📋 Step-Level Reporting
Each plugin reports granular `Step` results: name, start time, end time, success flag, and raw output. The dashboard drill-down shows exactly which step passed and which failed, down to the millisecond.

### 🗓️ Background Scheduler
A cron-based scheduler runs every minute to scan for pending jobs, enabling future support for fully automated, unattended regression runs.

### 🖼️ PNG Snapshots
Every completed run generates an image (`data/images/event-<id>.png`) that embeds the event summary alongside a pass/fail badge — useful for embedding results in reports, chat notifications, or tickets.

### 🗄️ PostgreSQL-Backed Persistence
Plugin metadata and run events are stored in Postgres, giving you a durable, queryable history of all test activity.

---

## Architecture

```
┌────────────────────────────────────────┐
│              A.R.T Host                │
│                                        │
│  ┌──────────┐   ┌────────────────────┐ │
│  │ Scheduler│   │   Gin HTTP Server  │ │
│  │ (cron)   │   │  /api/plugins      │ │
│  └──────────┘   │  /api/upload       │ │
│                 │  /api/events       │ │
│                 └────────┬───────────┘ │
│                          │             │
│              ┌───────────▼──────────┐  │
│              │   go-plugin (RPC)    │  │
│              └───────────┬──────────┘  │
└──────────────────────────│─────────────┘
                           │ net/rpc
              ┌────────────▼────────────┐
              │    Plugin Binary        │
              │  BeforeTest() + Run()   │
              │  → []Step               │
              └─────────────────────────┘
```

The host and every plugin share a `Runner` interface defined in `shared/interface.go`. Communication happens over **net/rpc**, brokered by [hashicorp/go-plugin](https://github.com/hashicorp/go-plugin). A magic-cookie handshake (`ART_PLUGIN=runner`) prevents accidentally running incompatible binaries.

---

## How It Works

### 1. The `Runner` Interface

Every plugin implements two methods:

```go
type Runner interface {
    // BeforeTest is called first — use it for setup or precondition checks.
    BeforeTest(ctx RunContext) (string, error)
    // Run executes the main test logic and returns per-step results.
    Run(ctx RunContext) ([]Step, error)
}
```

`RunContext` carries runtime configuration (e.g., `Timeout`), and each `Step` records its own timing and outcome.

### 2. Plugin Registration

When you upload a binary via the web UI, A.R.T:
- Saves the binary to `data/plugins/`.
- Marks it executable.
- Appends metadata (name, description, service, filename) to `data/info.json`.

The plugin card appears on the dashboard immediately — no restart needed.

### 3. Running a Plugin

Hitting **▶ Run** (or `POST /api/plugins/:name`) causes the host to:
1. Launch the plugin binary as a subprocess via `go-plugin`.
2. Call `BeforeTest()` for setup.
3. Call `Run()` and collect `[]Step` results.
4. Persist the event to Postgres and generate a PNG snapshot.
5. Return the step-level JSON to the caller.

### 4. Browsing History

`GET /api/events` returns all recorded runs. The History table in the UI lets you click **Details** on any row to see the full step breakdown.

---

## Writing Your First Plugin

```go
package main

import (
    goplugin "github.com/hashicorp/go-plugin"
    "art/shared"
    "time"
)

type MyPlugin struct{}

func (p *MyPlugin) BeforeTest(ctx shared.RunContext) (string, error) {
    return "setup complete", nil
}

func (p *MyPlugin) Run(ctx shared.RunContext) ([]shared.Step, error) {
    start := time.Now()
    // ... your test logic ...
    return []shared.Step{
        {Name: "check-api", StartTime: start, EndTime: time.Now(), Success: true, Output: "200 OK"},
    }, nil
}

func main() {
    goplugin.Serve(&goplugin.ServeConfig{
        HandshakeConfig: shared.Handshake,
        Plugins: map[string]goplugin.Plugin{
            "runner": &shared.RunnerPlugin{Impl: &MyPlugin{}},
        },
    })
}
```

Build it, upload it, click **▶ Run** — that's it.

---

## Project Structure

```
art/
├── main.go          # Entry point — scheduler + web server + graceful shutdown
├── web.go           # Gin HTTP server, REST handlers, event log
├── scheduler.go     # Cron scheduler (every minute)
├── pg.go            # PostgreSQL connection and schema
├── utils.go         # PNG snapshot generation
├── shared/
│   └── interface.go # Runner interface, Step type, RPC wrappers, handshake
├── plugins/
│   └── demo/        # Reference plugin implementation
└── public/          # Static web assets (HTML, CSS, JS)
```

---

## Getting Started

```bash
# Build the demo plugin
go build -o bin/demo-plugin ./plugins/demo

# Run the server
go run .
# → http://localhost:8080
```

Upload the binary from the web UI, click **▶ Run**, and watch the results roll in.

---

A.R.T keeps the testing infrastructure thin and the plugin contract simple. If your test logic can be expressed as a Go binary that returns a slice of `Step`s, it belongs in A.R.T.
