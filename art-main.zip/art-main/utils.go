package main

import (
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"os"
	"strings"

	"golang.org/x/image/font"
	"golang.org/x/image/font/basicfont"
	"golang.org/x/image/math/fixed"
)

// GenerateTextImage creates a PNG image with misc/passed.png at the top-left corner
// and the given text below it. The text may contain newline characters for multi-line output.
// It returns an error if any file cannot be read or written.
func GenerateTextImage(text, outputPath string) error {
	const (
		imgWidth = 500
		padding  = 10
	)

	// Load the overlay image from misc/passed.png.
	of, err := os.Open("misc/passed.png")
	if err != nil {
		return err
	}
	defer func() {
		if cerr := of.Close(); cerr != nil && err == nil {
			err = cerr
		}
	}()
	overlayImg, err := png.Decode(of)
	if err != nil {
		return err
	}
	overlayBounds := overlayImg.Bounds()
	overlayH := overlayBounds.Dy()

	// Calculate total image height: top padding + overlay + gap + text rows + bottom padding.
	face := basicfont.Face7x13
	lineHeight := face.Metrics().Height.Ceil()
	lines := strings.Split(text, "\n")
	imgHeight := padding + overlayH + padding + lineHeight*len(lines) + padding

	// Create a new RGBA image with a white background.
	img := image.NewRGBA(image.Rect(0, 0, imgWidth, imgHeight))
	draw.Draw(img, img.Bounds(), &image.Uniform{color.White}, image.Point{}, draw.Src)

	// Draw the overlay image at the top-left corner (with padding).
	overlayDst := image.Rect(padding, padding, padding+overlayBounds.Dx(), padding+overlayH)
	draw.Draw(img, overlayDst, overlayImg, overlayBounds.Min, draw.Over)

	// Draw each line of text below the overlay image.
	d := &font.Drawer{
		Dst:  img,
		Src:  image.NewUniform(color.Black),
		Face: face,
	}
	textStartY := padding + overlayH + padding
	for i, line := range lines {
		d.Dot = fixed.P(padding, textStartY+lineHeight*(i+1))
		d.DrawString(line)
	}

	// Encode and write the PNG file.
	f, err := os.Create(outputPath)
	if err != nil {
		return err
	}
	defer func() {
		if cerr := f.Close(); cerr != nil && err == nil {
			err = cerr
		}
	}()

	err = png.Encode(f, img)
	return err
}
