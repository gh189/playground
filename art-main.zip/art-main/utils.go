package main

import (
	"bytes"
	"context"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"golang.org/x/image/font"
	"golang.org/x/image/font/basicfont"
	"golang.org/x/image/math/fixed"

	"art/shared"

	"github.com/go-resty/resty/v2"
	"github.com/google/uuid"
)

// bytedance/sonic
// tidwall/gjson

// baseDir is the directory that contains the running binary.
// All data paths are resolved relative to it so that the process
// can be invoked from any working directory.
var baseDir string

func init() {
	exe, err := os.Executable()
	if err != nil {
		panic("cannot determine executable path: " + err.Error())
	}
	// Resolve symlinks so we always get the real directory.
	exe, err = filepath.EvalSymlinks(exe)
	if err != nil {
		panic("cannot resolve executable symlinks: " + err.Error())
	}
	baseDir = filepath.Dir(exe)
}

// binPath returns an absolute path resolved relative to the binary's directory.
func binPath(rel string) string {
	return filepath.Join(baseDir, rel)
}

// EnsureDir ensures the given directory path exists,
// creating it (and any parents) if necessary.
func EnsureDir(path string) error {
	return os.MkdirAll(path, 0755)
}

// SyncPluginsFromDB fetches every plugin binary stored in the plugins table
// and writes it to data/plugins, overwriting any existing file with the same
// name. This ensures the on-disk plugin binaries stay in sync with the
// database (the source of truth) across restarts/deployments.
func SyncPluginsFromDB(ctx context.Context) error {
	rows, err := db.Query(ctx, `SELECT name, plugin_binary FROM plugins`)
	if err != nil {
		return fmt.Errorf("failed to query plugins: %w", err)
	}

	for _, row := range rows {
		name, ok := row["name"].(string)
		if !ok || name == "" {
			continue
		}
		binary, ok := row["plugin_binary"].([]byte)
		if !ok {
			continue
		}

		dst := binPath(filepath.Join("data/plugins", name))
		if err := os.WriteFile(dst, binary, 0755); err != nil {
			return fmt.Errorf("failed to write plugin %q: %w", name, err)
		}
		// Ensure the binary is executable even if the file already existed
		// with different permissions.
		if err := os.Chmod(dst, 0755); err != nil {
			return fmt.Errorf("failed to chmod plugin %q: %w", name, err)
		}
	}
	return nil
}

// RequestPGSecrets requests PostgreSQL secrets from the PG maker service by
// POSTing "database-name" and "receipt-url" as form data. It returns an error
// if the request fails or the service responds with a non-2xx status.
func RequestPGSecrets(databaseName, receiptURL string) error {
	resp, err := resty.New().R().
		SetFormData(map[string]string{
			"database-name": databaseName,
			"receipt-url":   receiptURL,
		}).
		Post(pgMakerURL)
	if err != nil {
		return fmt.Errorf("RequestPGSecrets: %w", err)
	}
	if resp.IsError() {
		return fmt.Errorf("RequestPGSecrets: unexpected status %d: %s", resp.StatusCode(), resp.String())
	}
	return nil
}

// RequestSPSSecrets requests secrets for the named component from the SPS.
// It POSTs a "receipt-url" (pointing
// back to this service's /api/keepie endpoint) and a random "nonce" as
// URL-encoded form data, identifying itself via the x-efx-component header.
// It returns an error if the request fails or the service responds with a
// non-2xx status.
func RequestSPSSecrets(name string) error {
	nonce := uuid.NewString()

	resp, err := resty.New().R().
		SetHeader("Content-Type", "application/x-www-form-urlencoded").
		SetHeader("x-efx-component", "automator").
		SetFormData(map[string]string{
			"receipt-url": fmt.Sprintf("%s/api/keepie", selfURL),
			"nonce":       nonce,
		}).
		Post(fmt.Sprintf("%s/keepie/automator/secrets/%s/v1", spsURL, name))
	if err != nil {
		return fmt.Errorf("RequestSPSSecrets: %w", err)
	}
	if resp.IsError() {
		return fmt.Errorf("RequestSPSSecrets: failed to request sps secrets: %s", resp.String())
	}

	log.Printf("Response code from sps server: %d", resp.StatusCode())
	log.Print(resp.String())
	return nil
}

// GenerateEventImage creates a PNG evidence image documenting a single plugin
// run. It places the misc/passed.png banner at the top-left corner, followed
// by the event's metadata (ID, timestamp, plugin, result) and a table listing
// every step's name, start time, duration, status and output — mirroring the
// history detail view shown in the web UI. The generated PNG is written to
// outputPath and its raw bytes are also returned so callers can persist the
// same image elsewhere (e.g. as evidence in the database).
func GenerateEventImage(eventID int, timestamp time.Time, pluginName, summary string, steps []shared.Step, outputPath string) ([]byte, error) {
	const (
		imgWidth = 680
		padding  = 16
		rowPad   = 10 // extra vertical padding within each table row
	)

	// Column x-offsets for the steps table, chosen to roughly match the
	// proportions of the history detail view in the web UI.
	const (
		colStepX     = padding + 8
		colStartX    = 150
		colDurationX = 260
		colStatusX   = 370
		colOutputX   = 470
	)

	labelColor := color.RGBA{R: 124, G: 111, B: 224, A: 255} // purple accent, matches UI labels
	textColor := color.RGBA{R: 30, G: 30, B: 30, A: 255}
	headerBg := color.RGBA{R: 237, G: 239, B: 246, A: 255}
	rowBorder := color.RGBA{R: 230, G: 232, B: 240, A: 255}
	passColor := color.RGBA{R: 22, G: 163, B: 74, A: 255}
	failColor := color.RGBA{R: 220, G: 38, B: 38, A: 255}

	// Load the overlay image from the embedded public/images/passed.png.
	of, err := staticFiles.Open("public/images/passed.png")
	if err != nil {
		return nil, err
	}
	defer func() {
		if cerr := of.Close(); cerr != nil && err == nil {
			err = cerr
		}
	}()
	overlayImg, err := png.Decode(of)
	if err != nil {
		return nil, err
	}
	overlayBounds := overlayImg.Bounds()
	overlayH := overlayBounds.Dy()

	face := basicfont.Face7x13
	lineHeight := face.Metrics().Height.Ceil()
	rowHeight := lineHeight + rowPad

	// Compute total image height up front: banner, metadata rows, the
	// "STEPS" heading, the table header row, and one row per step (or a
	// single "no steps" row when there are none).
	metaRows := 4 // ID, Timestamp, Plugin, Result
	rowCount := len(steps)
	if rowCount == 0 {
		rowCount = 1
	}
	imgHeight := padding + overlayH + padding + // banner
		lineHeight*metaRows + padding + // metadata block
		lineHeight + padding/2 + // "STEPS" heading
		rowHeight + // table header row
		rowHeight*rowCount + // table body rows
		padding // bottom padding

	img := image.NewRGBA(image.Rect(0, 0, imgWidth, imgHeight))
	draw.Draw(img, img.Bounds(), &image.Uniform{color.White}, image.Point{}, draw.Src)

	// Draw the overlay image at the top-left corner (with padding).
	overlayDst := image.Rect(padding, padding, padding+overlayBounds.Dx(), padding+overlayH)
	draw.Draw(img, overlayDst, overlayImg, overlayBounds.Min, draw.Over)

	d := &font.Drawer{Dst: img, Face: face}
	drawText := func(x, y int, c color.Color, s string) {
		d.Src = image.NewUniform(c)
		d.Dot = fixed.P(x, y)
		d.DrawString(s)
	}

	// Metadata block (ID / Timestamp / Plugin / Result).
	y := padding + overlayH + padding + lineHeight
	for _, kv := range []struct{ label, value string }{
		{"ID", strconv.Itoa(eventID)},
		{"TIMESTAMP", timestamp.Format("2006/1/2 15:04:05")},
		{"PLUGIN", pluginName},
		{"RESULT", summary},
	} {
		drawText(padding, y, labelColor, kv.label)
		drawText(padding+110, y, textColor, kv.value)
		y += lineHeight
	}

	// "STEPS" heading.
	y += padding
	drawText(padding, y, labelColor, "STEPS")
	y += padding / 2

	// Table header row (with shaded background).
	headerTop := y
	draw.Draw(img, image.Rect(padding, headerTop, imgWidth-padding, headerTop+rowHeight),
		&image.Uniform{headerBg}, image.Point{}, draw.Src)
	textY := headerTop + rowHeight - rowPad/2 - 2
	drawText(colStepX, textY, labelColor, "Step")
	drawText(colStartX, textY, labelColor, "Start")
	drawText(colDurationX, textY, labelColor, "Duration")
	drawText(colStatusX, textY, labelColor, "Status")
	drawText(colOutputX, textY, labelColor, "Output")
	y = headerTop + rowHeight

	// Table body: one row per step, or a placeholder when there are none.
	if len(steps) == 0 {
		textY := y + rowHeight - rowPad/2 - 2
		drawText(colStepX, textY, textColor, "No steps recorded.")
		y += rowHeight
	} else {
		for _, s := range steps {
			rowTop := y
			draw.Draw(img, image.Rect(padding, rowTop+rowHeight-1, imgWidth-padding, rowTop+rowHeight),
				&image.Uniform{rowBorder}, image.Point{}, draw.Src)

			textY := rowTop + rowHeight - rowPad/2 - 2
			durMs := s.EndTime.Sub(s.StartTime).Milliseconds()
			var durText string
			if s.EndTime.IsZero() || s.StartTime.IsZero() {
				durText = "—"
			} else if durMs < 1000 {
				durText = fmt.Sprintf("%d ms", durMs)
			} else {
				durText = fmt.Sprintf("%.2f s", float64(durMs)/1000)
			}
			statusColor, statusText := failColor, "FAIL"
			if s.Success {
				statusColor, statusText = passColor, "PASS"
			}
			output := s.Output
			if output == "" {
				output = "—"
			}

			drawText(colStepX, textY, textColor, s.Name)
			drawText(colStartX, textY, textColor, s.StartTime.Format("15:04:05"))
			drawText(colDurationX, textY, textColor, durText)
			drawText(colStatusX, textY, statusColor, statusText)
			drawText(colOutputX, textY, textColor, output)

			y += rowHeight
		}
	}

	// Encode the PNG into memory so it can be both written to disk and
	// returned to the caller for further persistence (e.g. in the database).
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		return nil, err
	}

	if err := os.WriteFile(outputPath, buf.Bytes(), 0644); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}
